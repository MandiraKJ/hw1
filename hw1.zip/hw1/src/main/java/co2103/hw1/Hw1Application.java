package co2103.hw1;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import co2103.hw1.domain.Book;
import co2103.hw1.domain.Library;


@SpringBootApplication
public class Hw1Application implements CommandLineRunner {
	
	
	public static List<Library> libraries = new ArrayList<>();
	public static List<Book>books = new ArrayList<>();
	

	public static void main(String[] args) {
		SpringApplication.run(Hw1Application.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		Library library = new Library();
		library.setId(3);
		library.setName("Beep Boop");
		library.setAddress("221B Baker St London NW1 6XE");
		
		Book book = new Book();
		book.setAuthor("Haruki Murakami");
		book.setTitle("Desire");
		book.setPublisher("Random House");
		book.setPages(128);
		books.add(book);
			

		book = new Book();
		book.setAuthor("JK Rowling");
		book.setTitle("Harry Potter and the Goblet of Fire");
		book.setPublisher("Bloomsbury Publishing");
		book.setPages(636);
		books.add(book);
		
		library.setBooks(books);
		libraries.add(library);
		
		
	}


}


