package co2103.hw1.controller;


import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;




import co2103.hw1.Hw1Application;
import co2103.hw1.domain.Book;


@Controller

public class BookController {
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.addValidators(new BookValidator());
	}
	
	@GetMapping("/books")
	public String books(Model model) {
		model.addAttribute("books",Hw1Application.books);
		return "books/list";
	}


	@RequestMapping("/newBook")
	public String newLibrary(Model model) {
		model.addAttribute("book", new Book());
		return "books/form";
	}
	
	
	
	@PostMapping("/addTask")
	public String addBook(@Valid @ModelAttribute Book book, BindingResult result) {
		
		if (result.hasErrors()) {
			return "books/form";
		}
		Hw1Application.books.add(book);
		return "redirect:/libraries";
	
	
}
	

	}
