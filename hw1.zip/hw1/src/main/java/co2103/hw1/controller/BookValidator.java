package co2103.hw1.controller;


import java.util.Arrays;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import co2103.hw1.domain.Book;


public class BookValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return Book.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "title", "", "Your book needs a title!");
		ValidationUtils.rejectIfEmpty(errors, "author", "", "Your book needs an author!");
		
		Book b = (Book) target;
		
		String[] publisher = new String[] { "Springer", "IEEE", "ACM" };
		if(!Arrays.asList(publisher).contains(b.getPublisher())) {
			errors.rejectValue("publisher", "", "Invalid publisher.");
		}
		
		if(b.getPages() <= 5) {
			errors.rejectValue("pages", "", "Invalid number of pages.");
		} else if(b.getPages() >=1000) {
			errors.rejectValue("pages", "", "Invalid number of pages.");
			
		}
		
	}
}

