package co2103.hw1.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import co2103.hw1.Hw1Application;
import co2103.hw1.domain.Library;


@Controller
public class LibraryController {
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.addValidators(new LibraryValidator());
	}

	@GetMapping("/libraries")
	public String libraries(Model model) {
		model.addAttribute("libraries", Hw1Application.libraries);
		return "libraries/list";
	}

	
	
	@RequestMapping("/newLibrary")
	public String newLibrary(Model model) {
		model.addAttribute("library", new Library());
		return "libraries/form";
	}
	
	
	@PostMapping("/addLibrary")
	public String addLibrary(@Valid @ModelAttribute Library library, BindingResult result) {
		if (result.hasErrors()) {
			return "libraries/form";
		}
		Hw1Application.libraries.add(library);
		return "redirect:/libraries";
	}



	
}

	
