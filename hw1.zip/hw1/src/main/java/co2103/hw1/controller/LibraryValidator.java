package co2103.hw1.controller;



import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;



import co2103.hw1.Hw1Application;
import co2103.hw1.domain.Library;


public class LibraryValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return Library.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "", "Your library needs a name!");
		ValidationUtils.rejectIfEmpty(errors, "address", "", "Your library needs an address!");
		
		Library library = (Library) target;
		
		if (library.getAddress().length()<20){
			errors.rejectValue("address", "", "Your address is too short.");
		}
		for (Library l : Hw1Application.libraries) {
			if (l.getId() == library.getId()) {
				errors.rejectValue("id", "", "The ID of the library is already taken.");
			}
		}
		

	}

}
