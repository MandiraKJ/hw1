package co2103.hw1.domain;


public class Book {
	
	private String author;
	private String title;
	private String publisher;
	private int pages;
	

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getPublisher() {
		return publisher;
	}
	
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
	public int getPages() {
		return pages;
	}
	
	public void setPages(int pages){
		this.pages = pages;
	}
	
}


